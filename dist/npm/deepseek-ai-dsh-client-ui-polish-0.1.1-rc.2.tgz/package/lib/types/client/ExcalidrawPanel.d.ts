import '@excalidraw/excalidraw/dist/prod/index.css';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full component props: conversation view share + the ui-polish locale seat. */
export type ExcalidrawPanelProps = PropsRuntime<'conversation.view'> & PropsLocale<'ui-polish'>;
/**
 * Render the Excalidraw canvas as a conversation view tab, embedded directly.
 * @param props - composed slot props.
 * @returns the panel element tree.
 */
export declare function ExcalidrawPanel({ useSession, useWorkspaces, t }: ExcalidrawPanelProps): import("react").JSX.Element;
//# sourceMappingURL=ExcalidrawPanel.d.ts.map