import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Injected business face: read the current card text and persist a change. */
export interface PricingRowInjected {
    /** Current card JSON text (the user card when set, else the formatted seed). */
    currentJson: string;
    /** Whether a user card is currently set (false = the seed card applies). */
    hasCustom: boolean;
    /**
     * Validate and persist a card from JSON text.
     * @param json - rate card JSON text.
     * @throws {Error} with a field-level message when the card is invalid.
     */
    save: (json: string) => void;
    /** Clear the user card back to the built-in seed. */
    reset: () => void;
}
/** Full component props: runtime share + locale seat + injected pricing face. */
export type PricingRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'ui-polish'> & PricingRowInjected;
/**
 * Render the model rate card row.
 * @param props - composed slot props.
 */
export declare function PricingRow({ t, currentJson, hasCustom, save, reset }: PricingRowProps): import("react").JSX.Element;
//# sourceMappingURL=PricingRow.d.ts.map