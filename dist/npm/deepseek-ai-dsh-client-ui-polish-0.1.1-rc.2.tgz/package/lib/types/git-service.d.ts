/**
 * Git panel host service: a small REST surface over a workspace repository.
 * Executes `git` through `execFile` with array arguments (no shell), so
 * user-supplied paths and messages never reach a shell. Exposed routes (all
 * under `/git`, registered by the plugin apply):
 *
 *  - `GET  /git/status?cwd=<path>`      → branch + working-tree status.
 *  - `GET  /git/log?cwd=<path>&n=<n>`   → recent commit one-liners.
 *  - `POST /git/commit` {cwd, message}  → `git add -A` + `git commit -m`.
 *  - `POST /git/push` {cwd}             → `git push`.
 *  - `POST /git/diff` {cwd, path}       → `git diff -- <path>`.
 *  - `POST /git/read` {cwd, path}       → UTF-8 file content (view/edit).
 *  - `POST /git/write` {cwd, path, content} → overwrite the file in place.
 *  - `POST /git/list` {cwd, dir?}       → directory entries (files + subdirs).
 *
 * The target directory is chosen per request from `cwd`, which the host
 * resolves against its known workspace paths — an unknown directory is
 * rejected, so the surface can never be pointed at an arbitrary path.
 * Responses are JSON; errors carry an `error` field.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
/** One working-tree file in the porcelain status view. */
export interface GitStatusEntry {
    /** Two-letter porcelain status (e.g. " M", "??"). */
    readonly status: string;
    /** Repository-relative path (may include quotes for special names). */
    readonly path: string;
}
/** Response of `GET /git/status`. */
export interface GitStatusResult {
    readonly branch: string;
    readonly entries: readonly GitStatusEntry[];
    readonly isRepo: boolean;
}
/** Response of `GET /git/log`. */
export interface GitLogResult {
    readonly commits: readonly string[];
}
/** Resolve a requested cwd against the host's known workspace paths. */
export type GitCwdResolver = (requested: string) => string;
/**
 * Default resolver: only an exact match against a known workspace path is
 * accepted; everything else falls back to the host process cwd (the harness
 * checkout for a local `dsh web` run).
 * @param known - the host's current workspace paths.
 * @param fallback - host process cwd.
 * @returns the resolver.
 */
export declare function workspaceCwdResolver(known: readonly string[], fallback: string): GitCwdResolver;
/** Normalize Windows separators so path matching is robust.
 * @param path - path to normalize.
 * @returns the path with backslashes replaced by slashes and trailing slashes trimmed.
 */
export declare function normalizeSlashes(path: string): string;
/**
 * The git panel route handler: one prefix route owning every `/git` endpoint.
 * @param resolveCwd - resolves the requested cwd against known workspaces.
 * @param req - incoming HTTP request.
 * @param res - server response.
 */
export declare function handleGitRequest(resolveCwd: GitCwdResolver, req: IncomingMessage, res: ServerResponse): Promise<void>;
//# sourceMappingURL=git-service.d.ts.map