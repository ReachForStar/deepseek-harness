import type { PropsLocale, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createBackgroundRowStore } from './settings-store.ts';
/** Injected business face: the background write (t rides the standard locale seat). */
export interface BackgroundRowInjected {
    /** Set (data URL) or clear (null) the whole-app background image. */
    setBackgroundImage: (dataUrl: string | null) => void;
}
/** Full component props: runtime share + store share + locale seat + injected face. */
export type BackgroundRowComponentProps = PropsRuntime<'settings.general.item'> & PropsStore<ReturnType<typeof createBackgroundRowStore>> & PropsLocale<'ui-polish'> & BackgroundRowInjected;
/**
 * Render the background image row.
 * @param props - composed slot props.
 * @returns the row element tree.
 */
export declare function BackgroundRow({ t, setBackgroundImage, useStore }: BackgroundRowComponentProps): import("react").JSX.Element;
//# sourceMappingURL=BackgroundRow.d.ts.map