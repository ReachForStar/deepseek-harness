import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full component props: conversation view share + the ui-polish locale seat. */
export type GitPanelProps = PropsRuntime<'conversation.view'> & PropsLocale<'ui-polish'>;
/**
 * Render the git panel as a conversation view tab.
 * @param props - composed slot props.
 * @returns the panel element tree.
 */
export declare function GitPanel({ useSession, useWorkspaces, t }: GitPanelProps): import("react").JSX.Element;
//# sourceMappingURL=GitPanel.d.ts.map