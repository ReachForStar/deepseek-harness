import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { DiffHunk } from '@deepseek-ai/dsh-client-ui-primitives';
/** One settled file-mutation call with the applied hunks the panel draws. */
export interface SettledDiffCall {
    callId: string;
    /** Tool display name, falling back to the callId when the head left the window. */
    name: string;
    /** Validated applied hunks. */
    diffs: DiffHunk[];
}
/** One tool-operated file path with the tool that touched it. */
export interface TouchedFile {
    /** Tool display name (read/edit/write/…). */
    tool: string;
    /** Repository/workspace-relative file path. */
    path: string;
}
/**
 * Narrow a wire `card:'diff'` view's `diffs` to well-formed hunks. The view
 * crosses the wire, so a version mismatch or an anomalous plugin can deliver a
 * `diff` card whose `diffs` is absent, not an array, or carries malformed
 * hunks; returning null routes the call out instead of crashing DiffBlock.
 * @param diffs - the view's `diffs` field, unverified.
 * @returns the validated hunks, or null when the payload is not usable.
 */
export declare function narrowDiffs(diffs: unknown): DiffHunk[] | null;
/**
 * Collect the session's settled file-mutation calls in node-store iteration
 * order. A running or errored mutation is excluded: without an applied diff
 * there is nothing to show.
 * @param snapshot - the session's conversation snapshot.
 * @returns settled diff calls with their applied hunks, in store order.
 */
export declare function settledDiffCalls(snapshot: ConversationSnapshot): SettledDiffCall[];
/**
 * Collect every file path a settled tool call operated on (read/edit/write),
 * deduplicated in store order. Read cards carry the file path in `resultView.path`;
 * diff cards carry it per hunk.
 * @param snapshot - the session's conversation snapshot.
 * @returns touched file paths with the tool that touched them.
 */
export declare function touchedFiles(snapshot: ConversationSnapshot): TouchedFile[];
//# sourceMappingURL=settled-diffs.d.ts.map