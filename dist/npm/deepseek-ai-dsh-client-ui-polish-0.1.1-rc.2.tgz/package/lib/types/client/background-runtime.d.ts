import type { Context } from '@deepseek-ai/cordis';
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import { type PolishSettings } from '../background-settings.ts';
/** Body attribute marking that a whole-app background image is active. */
export declare const BG_IMAGE_ATTRIBUTE = "data-ds-bg-image";
/**
 * Background preference owner and DOM painter. Reads go through
 * {@link getBackgroundImage} and {@link subscribe}; writes only through
 * {@link setBackgroundImage} (set for a data URL, unset for null).
 */
export declare class BackgroundRuntime {
    private readonly host;
    private backgroundImage;
    private readonly listeners;
    /**
     * @param ctx - owning context (scope subscription rides ctx.effect).
     * @param host - durable preference scope bound by the owning plugin.
     */
    constructor(ctx: Context, host: SettingsScope<PolishSettings>);
    /** The current background image data URL, or null when none is set.
     * @returns the served image URL or null.
     */
    getBackgroundImage(): string | null;
    /**
     * Observe background value changes.
     * @param listener - invoked after each accepted change.
     * @returns the disposer removing this listener.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Set or clear the whole-app background image. A data URL is written through
     * the settings scope; null clears the field. Every accepted change repaints
     * the body and notifies listeners.
     * @param dataUrl - uploaded image data URL, or null to remove the background.
     */
    setBackgroundImage(dataUrl: string | null): void;
    /** Adopt the scope's accepted durable value without writing it back. */
    private adopt;
    /** Paint or clear the background on the body, setting `data-ds-bg-image`. */
    private paint;
    private notify;
    /** Retract every body write this runtime made. */
    dispose(): void;
}
//# sourceMappingURL=background-runtime.d.ts.map