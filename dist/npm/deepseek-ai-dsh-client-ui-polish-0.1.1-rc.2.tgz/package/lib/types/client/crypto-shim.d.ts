/**
 * 浏览器端 node:crypto 最小 shim。Excalidraw 依赖树内的 nanoid（3.x CJS 与 4.x
 * node 版构建）在模块顶层引用 "crypto" 的 `randomFillSync`，uuid@14 的 node 版
 * 引用 `createHash`（md5/sha1）与全局 `Buffer`；浏览器都没有这些 API。这里用
 * Web Crypto 与纯 JS 摘要实现等价物，顶层副作用同时兜底 `Buffer` 全局（其随机
 * 池/字节随即被 randomFillSync 覆盖写满，返回普通 Uint8Array 即可）。
 */
/** 用 Web Crypto 随机字节填满缓冲（node:crypto.randomFillSync 的浏览器等价物）。
 * @param buffer - 待填满的字节缓冲。
 * @returns 同一缓冲（已填满随机字节）。
 */
export declare function randomFillSync(buffer: Uint8Array): Uint8Array;
/** 生成指定字节数的随机字节（node:crypto.randomBytes 的浏览器等价物）。
 * @param size - 字节数。
 * @returns 随机字节缓冲。
 */
export declare function randomBytes(size: number): Uint8Array;
/** 生成随机 UUID v4（node:crypto.randomUUID 的浏览器等价物）。
 * @returns UUID v4 字符串。
 */
export declare function randomUUID(): string;
/** Web Crypto 对象本体。 */
export declare const webcrypto: Crypto;
/** 填充任意 ArrayBufferView（node:crypto.getRandomValues 的浏览器等价物）。
 * @param array - 待填充的 ArrayBufferView。
 * @returns 同一视图（已填充随机字节）。
 */
export declare function getRandomValues<T extends ArrayBufferView<ArrayBuffer>>(array: T): T;
/** node:crypto.createHash 的同步浏览器等价物（支持 md5 与 sha1）。
 * @param algorithm - 摘要算法名（md5 或 sha1）。
 * @returns 链式 update 后经 digest 产出摘要的句柄。
 */
export declare function createHash(algorithm: 'md5' | 'sha1'): {
    update(data: Uint8Array | string): unknown;
    digest(): Uint8Array;
};
/** 兼容 default import（nanoid 3.x 以 `import crypto from 'crypto'` 引用）。 */
declare const _default: {
    randomFillSync: typeof randomFillSync;
    randomBytes: typeof randomBytes;
    randomUUID: typeof randomUUID;
    webcrypto: Crypto;
    getRandomValues: typeof getRandomValues;
    createHash: typeof createHash;
};
export default _default;
//# sourceMappingURL=crypto-shim.d.ts.map