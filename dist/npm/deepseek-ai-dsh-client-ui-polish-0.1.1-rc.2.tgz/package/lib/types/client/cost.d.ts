import type { TokenUsageProjection } from '@deepseek-ai/dsh-token-meter/client';
/** One flat model's prices in CNY per 1M tokens; cache fields may be absent. */
export interface FlatRateCard {
    inputPerMillion: number;
    outputPerMillion: number;
    cacheReadPerMillion?: number;
    cacheWritePerMillion?: number;
}
/** One time tier (deepseek peak/off-peak). */
export interface TimeTier {
    name: string;
    inputPerMillion: number;
    outputPerMillion: number;
    cacheReadPerMillion?: number;
}
/** One length tier with its upper bound (omitted on the catch-all final tier). */
export interface LenTier {
    name: string;
    maxLen?: number;
    inputPerMillion?: number;
    outputPerMillion?: number;
    cacheReadPerMillion?: number;
    cacheWritePerMillion?: number;
}
/** A model's billing mode (mirrors the JSON structure: nested per-mode payloads). */
export type ModelBilling = {
    mode: 'flat';
    flat: FlatRateCard;
} | {
    mode: 'time';
    time: {
        timezone: string;
        peak: readonly {
            startMinute: number;
            endMinute: number;
        }[];
        tiers: readonly TimeTier[];
    };
} | {
    mode: 'len';
    len: {
        tiers: readonly LenTier[];
    };
};
/** One complete rate card: the fallback card plus per-model billing modes. */
export interface RateCardData {
    /** Fallback card for unknown models. */
    default: FlatRateCard;
    /** Model-name → billing mode. */
    models: Readonly<Record<string, ModelBilling>>;
}
/** The built-in seed card (deepseek-v4-flash off-peak: input 1.5 / output 4.5 / cache read 0.05). */
export declare const DEFAULT_RATE_CARD: FlatRateCard;
/** The built-in seed model table. */
export declare const DEFAULT_MODEL_BILLING: Readonly<Record<string, ModelBilling>>;
/** The complete built-in seed card. */
export declare const SEED_RATE_CARD: RateCardData;
/**
 * Parse and validate a user-supplied rate card from JSON text. The accepted
 * shape mirrors `model-pricing.json`: `{ default: FlatRateCard, models: {
 * [model]: { mode, flat | time | len } } }`. A `$comment` key is ignored.
 * @param json - the raw JSON text from the settings document.
 * @returns the validated card.
 * @throws {Error} with a field-level message when the JSON is malformed or a price is invalid.
 */
export declare function parseRateCard(json: string): RateCardData;
/**
 * Resolve the billing mode for one model id: exact match on the card, a
 * case-insensitive match as a fallback, then a flat card at the fallback
 * rates (the card's `default`, or the built-in seed when none is supplied).
 * @param model - the model id (from an assistant node's provenance).
 * @param models - the card's model table (defaults to the built-in seed).
 * @param fallback - the flat card unknown models fall back to (defaults to the seed).
 * @returns the effective billing mode for the model.
 */
export declare function billingFor(model: string, models?: Readonly<Record<string, ModelBilling>>, fallback?: FlatRateCard): ModelBilling;
/** Sum the three disjoint prompt-side billing buckets.
 * @param usage - the message's token usage projection.
 * @returns uncached + cache-read + cache-write input tokens.
 */
export declare function billedInputTokens(usage: TokenUsageProjection): number;
/**
 * Resolve the price tier for one message under its model's billing mode.
 * @param billing - the model's billing mode.
 * @param usage - the message's token usage (length tiers use billed input tokens).
 * @param at - the message's wall-clock instant (time tiers use Asia/Shanghai minute).
 * @param fallback - the card's default rates used for absent tier fields.
 * @returns the flat card or the selected tier's prices.
 */
export declare function tierFor(billing: ModelBilling, usage: TokenUsageProjection, at: number, fallback?: FlatRateCard): FlatRateCard;
/** Estimated spend in CNY for one message at its model's rate and time.
 * @param usage - the message's token usage projection.
 * @param model - the model id (from an assistant node's provenance).
 * @param at - the message's wall-clock instant.
 * @param card - the rate card to bill against (defaults to the built-in seed).
 * @returns the estimated spend in yuan.
 */
export declare function estimateCost(usage: TokenUsageProjection, model: string, at: number, card?: RateCardData): number;
/** Per-bucket cost split for one message, mirroring {@link estimateCost}.
 * @param usage - the message's token usage projection.
 * @param model - the model id (from an assistant node's provenance).
 * @param at - the message's wall-clock instant.
 * @param card - the rate card to bill against (defaults to the built-in seed).
 * @returns the input/cache/output bucket split in yuan.
 */
export declare function costBreakdown(usage: TokenUsageProjection, model: string, at: number, card?: RateCardData): {
    input: number;
    cache: number;
    output: number;
};
/** Cumulative cost over a model-keyed usage map, priced per message at its own time. */
export interface CostTotals {
    input: number;
    cache: number;
    output: number;
    total: number;
    /** Per-model subtotals for the breakdown row. */
    models: {
        model: string;
        cost: number;
    }[];
}
/**
 * Accumulate totals over per-message usages, each priced at its model's rate
 * and its own wall-clock instant (time-tiered models switch price by hour).
 * @param messages - message usages with model and settled timestamp.
 * @param card - the rate card to bill against (defaults to the built-in seed).
 * @returns summed buckets, total, and per-model subtotals.
 */
export declare function accumulateCost(messages: readonly {
    usage: TokenUsageProjection;
    model: string;
    at: number;
}[], card?: RateCardData): CostTotals;
/**
 * CNY display string: two decimals with thousands grouping; sub-cent amounts
 * read as ¥0.00 (the caller hides the cost row entirely at that scale).
 * @param cost - estimated cost in yuan.
 * @returns the display string, `¥` prefix included.
 */
export declare function formatCost(cost: number): string;
//# sourceMappingURL=cost.d.ts.map