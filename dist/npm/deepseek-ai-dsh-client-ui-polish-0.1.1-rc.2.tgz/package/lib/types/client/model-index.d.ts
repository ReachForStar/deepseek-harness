import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-runtime/client';
/** Minimal state machine: nothing to fold, the event is the whole fact. */
type EmptyState = Record<string, never>;
/**
 * Apply-owned model index: a plain messageId → model map plus the write and
 * read faces. Message ids are globally unique, and the Definition runs across
 * every session, so one map serves the whole app; the stats float looks up by
 * the message id its node carries. No reactivity is needed — the component's
 * node subscription already drives re-renders, and a settled message's model
 * never changes.
 */
export interface ModelIndex {
    /** Record one settled assistant message's model (idempotent by messageId). */
    readonly record: (messageId: string, model: string) => void;
    /** Resolve one message id's model; undefined when not yet recorded. */
    readonly modelOf: (messageId: string) => string | undefined;
}
/** Create the apply-owned model index (one per plugin instance, never module-level).
 * @returns the messageId → model index handle.
 */
export declare function createModelIndex(): ModelIndex;
/**
 * One-session Definition recording the model of every settled assistant
 * message. State-only: it publishes no view node; the record side effect feeds
 * the stats float's per-model billing. Replays are idempotent — `record`
 * overwrites by messageId, and message ids are globally unique.
 * @param index - the apply-owned model index to write.
 * @returns the Definition contribution.
 */
export declare function modelIndexDefinition(index: ModelIndex): ConversationNodeDefinition<EmptyState>;
export {};
//# sourceMappingURL=model-index.d.ts.map