/**
 * Model-facing Excalidraw scene tools. The agent reads the current workspace's
 * canvas scene (the same file the canvas tab persists to at
 * `<workspace>/.dsh/excalidraw/scene.json`) and writes it back, so model
 * edits land in the exact file the whiteboard renders. All tools derive the
 * target workspace from the calling agent's session; a non-agent caller has no
 * owning workspace and is rejected.
 *
 *  - `excalidraw_read`  → scene summary + full JSON when the file is small.
 *  - `excalidraw_write` → overwrite the workspace scene from a JSON string.
 *  - `excalidraw_draw`  → add/replace shapes from a high-level description.
 *  - `excalidraw_export` → write the scene as an SVG file in the workspace.
 *
 * `excalidraw_draw` is the everyday path: the model describes shapes at a high
 * level (`{type, x, y, width, height, text?}`) and this tool produces minimal
 * elements that Excalidraw's `updateScene` completes (seed/version/index are
 * auto-filled), so the model never hand-writes internal element fields.
 *
 * This package is the cordis plugin mounting the tools; the same scene file
 * convention (`SCENE_RELATIVE`) is shared with the web surface's `/scene`
 * routes in `@deepseek-ai/dsh-client-ui-polish`.
 * @module @deepseek-ai/dsh-tool-excalidraw
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "tool-excalidraw";
/** Services required by the Excalidraw scene tools. */
export declare const inject: string[];
/** Relative scene file inside a workspace (shared with the web `/scene` routes). */
export declare const SCENE_RELATIVE: string;
/**
 * Render an Excalidraw scene as an SVG document. Pure node-side (no canvas):
 * the model's `excalidraw_export` tool writes this vector file to the
 * workspace. Supports the shapes the draw tool emits plus freedraw paths;
 * hand-drawn (roughjs) texture is not reproduced — flat fills/strokes only.
 * @param elements - the scene's element objects.
 * @param background - backdrop color, or null for transparent.
 * @returns the SVG document as a string.
 */
export declare function sceneToSvg(elements: readonly unknown[], background: string | null): string;
/**
 * Register the four Excalidraw scene tools into the composed tool registry.
 * @param ctx - Host context with the tools and workspaceRegistry services.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map