import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { TokenUsageProjection } from '@deepseek-ai/dsh-token-meter/client';
import { type RateCardData } from './cost.ts';
/** Compact token count: 517 / 12.2K / 517K / 1.2M (one decimal under three digits). */
export declare function formatTokens(n: number): string;
/** Compact duration: 45.2s under a minute, 2m42s from there on. */
export declare function formatDuration(ms: number): string;
/** Compact throughput: 152 / 12.4 tok/s (one decimal under ten). */
export declare function formatTokensPerSecond(rate: number): string;
/** One cost-attributable assistant message: usage, model, and settled time. */
export interface MessageCostInput {
    usage: TokenUsageProjection;
    model: string;
    /** Unix epoch ms when the message settled (drives time-tiered pricing). */
    at: number;
}
/**
 * Cost-attributable messages over the settled assistant nodes in the window.
 * Each finalized message carries its own provider usage, model, and settle
 * time, so a session that switched models or crossed a peak/off-peak boundary
 * bills each step at its own rate. Nodes without a model or without usage are
 * skipped; the caller falls back to the durable projection when nothing is
 * attributable.
 * @param nodes - the conversation snapshot's legacy nodes.
 * @param modelOf - the plugin's messageId → model index lookup.
 * @returns per-message cost inputs; empty when no node carries both.
 */
export declare function messageCosts(nodes: readonly ConversationSnapshot['chat']['legacy']['nodes'][number][], modelOf: (messageId: string) => string | undefined): MessageCostInput[];
/** Full component props: session runtime share + the ui-polish locale seat + injected model index. */
export type StatsFloatProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'ui-polish'> & {
    /** Resolve one settled assistant message's model id (plugin-owned index). */
    modelOf: (messageId: string) => string | undefined;
    /** The rate card pricing the float (the user card, or the built-in seed). */
    card: RateCardData;
};
export declare const StatsFloat: import("react").MemoExoticComponent<({ useSession, useProjection, t, modelOf, card }: StatsFloatProps) => import("react").JSX.Element | null>;
//# sourceMappingURL=StatsFloat.d.ts.map