import type { Context } from '@deepseek-ai/cordis';
import type { SettingsScope } from '@deepseek-ai/dsh-settings';
import type { PolishSettings } from './background-settings.ts';
/**
 * The user-chosen ratio read from the settings scope, or undefined when not set.
 * @param scope - the ui-polish settings scope (already bound by the caller).
 * @returns the ratio when configured, else undefined (harness default applies).
 */
export declare function configuredRatio(scope: SettingsScope<PolishSettings>): number | undefined;
/**
 * Install the configurable automatic-compaction listener. It fires before the
 * harness's own pre-step listener (this plugin registers at app start, before
 * preset mounts) and only when the user's ratio is strictly below the harness
 * default, so it can never double-compact with the built-in 0.8 listener.
 * @param ctx - host context with settings, agentPresets, llm, tokenMeter.
 * @param scope - the ui-polish settings scope (bound by the caller).
 */
export declare function installCompactionControl(ctx: Context, scope: SettingsScope<PolishSettings>): void;
//# sourceMappingURL=compaction-control.d.ts.map