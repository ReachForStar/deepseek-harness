/** Host registration for the ui-polish background-image preference and git panel. */
import type { Context } from '@deepseek-ai/cordis';
export { BACKGROUND_IMAGE_FIELD, BACKGROUND_SETTINGS_NAMESPACE, MAX_BACKGROUND_IMAGE_BYTES, type PolishSettings, } from './background-settings.ts';
export { handleBackgroundRequest, BACKGROUND_IMAGE_FILE } from './background-service.ts';
export { handleExcalidrawRequest } from './excalidraw-service.ts';
export { handleGitRequest, workspaceCwdResolver, type GitCwdResolver, type GitLogResult, type GitStatusEntry, type GitStatusResult } from './git-service.ts';
/**
 * Register the durable background section and the git panel HTTP surface when
 * the optional Host settings / webserver services are composed. The git panel
 * targets the workspace the browser is currently viewing: each request carries
 * the workspace path, resolved per request against the live workspace registry
 * so a workspace switch is followed without a restart.
 * @param ctx - Host context that may acquire the settings and webserver services.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map