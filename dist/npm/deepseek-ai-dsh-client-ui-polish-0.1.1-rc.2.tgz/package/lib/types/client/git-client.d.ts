/** Query-encode the cwd into a `/git` URL.
 * @param path - route path (e.g. `/git/list`).
 * @param cwd - workspace directory carried as the `cwd` query parameter.
 * @param params - additional query parameters.
 * @returns the URL with the query string attached.
 */
export declare function gitUrl(path: string, cwd: string, params?: Record<string, string>): string;
/** Fetch JSON from a git panel endpoint, throwing on HTTP or body errors.
 * @param path - route path (e.g. `/git/read`).
 * @param cwd - workspace directory the host resolves the request against.
 * @param init - fetch options; a JSON string body is merged with the cwd.
 * @returns the parsed JSON payload.
 * @throws {Error} when the response is not ok, with the body `error` message when present.
 */
export declare function gitFetch<T>(path: string, cwd: string, init?: RequestInit): Promise<T>;
//# sourceMappingURL=git-client.d.ts.map