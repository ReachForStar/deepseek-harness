import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type PolishKey } from './locales.ts';
export type { BackgroundRowComponentProps, BackgroundRowInjected } from './BackgroundRow.tsx';
export type { BackgroundRowState } from './settings-store.ts';
export type { PolishKey } from './locales.ts';
export type { PolishSettings } from '../background-settings.ts';
/** Namespace owning this plugin's copy. */
export declare const NS = "ui-polish";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The ui-polish surface's copy. */
        'ui-polish': PolishKey;
    }
}
/** Required services: settings transport plus slots/locale for the registrations. */
export declare const inject: string[];
/**
 * Client plugin body: bind the background preference, paint the body, and
 * register the three surface contributions.
 * @param ctx - client cordis context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map