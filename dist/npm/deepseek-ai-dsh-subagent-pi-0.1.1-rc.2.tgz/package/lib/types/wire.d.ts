/**
 * Minimal Pi coding agent 0.84 RPC protocol adapter. Pi RPC mode speaks a
 * line-delimited JSON protocol over stdio: commands are JSON objects with a
 * `type` field and an optional `id` for correlation, responses are
 * `{ id, type: "response", command, success, data | error }` objects, and the
 * session streams typed events (notably `agent_settled` when the agent turn
 * ends). This module owns framing, command correlation, the unattended
 * extension-UI answers, and terminal-answer retrieval; the process lifecycle
 * lives in `run.ts`.
 *
 * @module @deepseek-ai/dsh-subagent-pi/wire
 */
import type { Readable, Writable } from 'node:stream';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { SubagentResult } from '@deepseek-ai/dsh-subagent';
/**
 * One Pi RPC connection and its single session turn.
 *
 * The class deliberately exposes no generic command surface. Supporting
 * another Pi command must first become part of the provider contract.
 */
export declare class PiRpcWire {
    private readonly input;
    private readonly output;
    private readonly fatal;
    private readonly settled;
    private readonly pending;
    private buffer;
    private settledObserved;
    private closed;
    private nextId;
    constructor(input: Readable, output: Writable);
    /** Start reading Pi frames. */
    start(): void;
    /**
     * Prove the RPC server is ready by resolving one `get_state` command.
     * @param signal - unpublished-start cancellation.
     */
    ready(signal: AbortSignal): Promise<void>;
    /**
     * Submit the one text-only task. Resolves once Pi acknowledges preflight.
     * @param text - already validated task text.
     * @param signal - unpublished-start cancellation.
     */
    prompt(text: string, signal: AbortSignal): Promise<void>;
    /**
     * Wait for the current agent turn to settle (`agent_settled` event).
     * @param signal - local cancellation for the published run.
     */
    waitSettled(signal: AbortSignal): Promise<void>;
    /**
     * Read the final answer from the settled session: the last non-empty
     * assistant text, or undefined when Pi ended without one.
     * @param signal - local cancellation for the published run.
     * @returns the final assistant text, if any.
     */
    lastAssistantText(signal: AbortSignal): Promise<string | undefined>;
    /**
     * The terminal result of the one turn: the exact final assistant text when
     * Pi settled with an answer, else an error (Pi settled without one).
     * @param text - the already validated task text.
     * @param signal - local cancellation for the published run.
     * @returns the shared subagent result, or a rejection mapped to `error` by
     * the run settlement when Pi settled without an answer.
     */
    runTurn(text: string, signal: AbortSignal): Promise<SubagentResult>;
    /**
     * Best-effort remote cancellation. Local settlement and process teardown
     * remain authoritative when the child no longer accepts protocol commands.
     */
    abort(): void;
    /**
     * Output snapshot for cancellation and failure settlement. Pi's protocol
     * offers no committed partial-answer projection, so the snapshot is empty.
     * @returns no content blocks.
     */
    collectOutput(): ContentBlock[];
    /** Detach stream listeners and reject outstanding commands. Idempotent. */
    close(): void;
    private guarded;
    private request;
    private fail;
    private readonly onInputError;
    private readonly onOutputError;
    private readonly onInputEnd;
    private readonly onData;
    private handleLine;
    private handleFrame;
    private handleResponse;
    private handleExtensionUiRequest;
}
//# sourceMappingURL=wire.d.ts.map