/**
 * One-shot Pi coding agent child lifecycle: spawn the real Pi RPC server
 * through the subprocess seam, publish only after the RPC server is ready,
 * flatten post-publication failures, and dispose to whole-tree quiescence.
 *
 * @module @deepseek-ai/dsh-subagent-pi/run
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import { type SubagentRun, type SubagentStartRequest, type SubagentStopReason } from '@deepseek-ai/dsh-subagent';
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess';
import { PiRpcWire } from './wire.ts';
/** Default POSIX grace between subprocess termination tiers. */
export declare const DEFAULT_DISPOSE_GRACE_MS = 3000;
/** Default grace for Pi's cooperative EOF shutdown before termination. */
export declare const DEFAULT_DISPOSE_EOF_GRACE_MS = 6000;
/**
 * Resolve the Pi RPC command for a platform. Windows npm and pnpm installs
 * expose `pi.cmd`, which requires `cmd.exe`; the argv is constant (or, for a
 * configured `command`/`args` pair, validated deployment data), so no task or
 * configuration text enters the shell boundary.
 * @param platform - host platform used to select the executable boundary.
 * @param command - the Pi executable (bare name) or a test fixture launcher.
 * @param args - fixed Pi RPC arguments.
 * @returns argv for the Pi RPC command.
 */
export declare function piRpcArgv(platform?: NodeJS.Platform, command?: string, args?: readonly string[]): string[];
/** Fully resolved inputs for one Pi RPC run. */
export interface PiRunSpec {
    /** Parent Session workspace, also the child's working directory. */
    readonly cwd: string;
    /** Explicit deployment/test environment layered after the shared scrub. */
    readonly env: Record<string, string>;
    /** Pi executable (bare name) or a test fixture launcher. */
    readonly command: string;
    /** Fixed Pi RPC arguments. */
    readonly args: readonly string[];
    /** Grace for Pi's cooperative EOF shutdown before termination. */
    readonly disposeEofGraceMs: number;
    /** Subprocess termination grace passed to the shared process-tree owner. */
    readonly disposeGraceMs: number;
    /** Shared subprocess service spawn operation. */
    readonly spawn: (spec: SubprocessSpawnSpec) => SubprocessHandle;
    /** Diagnostic sink for a post-publication error flattened into a result. */
    readonly onError?: (error: Error, stopReason: SubagentStopReason) => void;
}
/**
 * Validate and preserve the one-shot task before crossing the process boundary.
 * @param prompt - task content accepted from the shared subagent service.
 * @returns the exact concatenated non-empty text task.
 */
export declare function textTask(prompt: readonly ContentBlock[]): string;
/**
 * Close the private wire, ask the child to shut down cooperatively through
 * stdin EOF, escalate to the shared process-tree termination after the EOF
 * grace, and wait for the subprocess owner to prove it is gone.
 * @param wire - private Pi RPC protocol connection.
 * @param child - shared-service handle that owns the process tree.
 * @param eofGraceMs - bound on the cooperative EOF shutdown window.
 */
export declare function disposePiChild(wire: PiRpcWire, child: SubprocessHandle, eofGraceMs: number): Promise<void>;
/**
 * Start the real `pi --mode rpc` child and publish its one-shot run.
 * @param request - resolved shared subagent request.
 * @param spec - workspace, environment, process service, and diagnostic policy.
 * @returns the published run after the RPC server answered its readiness probe.
 */
export declare function startPiRun(request: SubagentStartRequest, spec: PiRunSpec): Promise<SubagentRun>;
//# sourceMappingURL=run.d.ts.map