import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { COMPACTION_RATIO_FIELD, type PolishSettings } from '../background-settings.ts';
/** Injected business face: read the current ratio and persist a change. */
export interface CompactionRowInjected {
    /** Current ratio × 100, or null when unset (harness default applies). */
    currentRatio: number | null;
    /** Persist a ratio selection; null clears back to the harness default. */
    setRatio: (ratio: number | null) => void;
}
/** Full component props: runtime share + locale seat + injected compaction face. */
export type CompactionRowProps = PropsRuntime<'settings.general.item'> & PropsLocale<'ui-polish'> & CompactionRowInjected;
/**
 * Render the automatic-compaction threshold row.
 * @param props - composed slot props.
 */
export declare function CompactionRow({ t, currentRatio, setRatio }: CompactionRowProps): import("react").JSX.Element;
/** Type-only export so the plugin's inject face stays checkable. */
export type { PolishSettings };
export { COMPACTION_RATIO_FIELD };
//# sourceMappingURL=CompactionRow.d.ts.map