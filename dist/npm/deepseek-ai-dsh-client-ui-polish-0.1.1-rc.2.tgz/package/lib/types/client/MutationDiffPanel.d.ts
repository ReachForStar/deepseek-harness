import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full component props: conversation view share + the ui-polish locale seat. */
export type MutationDiffPanelProps = PropsRuntime<'conversation.view'> & PropsLocale<'ui-polish'>;
/**
 * Render the file panel as a conversation view tab browsing the workspace tree.
 * @param props - composed slot props.
 * @returns the panel element tree.
 */
export declare function MutationDiffPanel({ useSession, useWorkspaces, t }: MutationDiffPanelProps): import("react").JSX.Element;
//# sourceMappingURL=MutationDiffPanel.d.ts.map