/**
 * Excalidraw canvas host service: persists workspace scene files for the
 * embedded whiteboard (the Excalidraw component runs in the client bundle
 * directly — no separate page). Exposed routes (all under the `/scene`
 * prefix, registered by the plugin apply):
 *
 *  - `POST /scene/current` {cwd}    → the workspace scene JSON, or 404.
 *  - `POST /scene/write` {cwd, scene} → overwrite the workspace scene file.
 *
 * The target workspace is chosen per request from `cwd`, resolved against the
 * host's known workspace paths — an unknown directory is rejected, so the
 * surface can never be pointed at an arbitrary path (same guard as the git
 * panel). Scenes live at `<workspace>/.dsh/excalidraw/scene.json`, keeping
 * them out of the visible working tree. Responses are JSON; errors carry an
 * `error` field.
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { type GitCwdResolver } from './git-service.ts';
/**
 * Handle one `/scene` request.
 * @param resolveCwd - workspace-path resolver (see {@link GitCwdResolver}).
 * @param req - incoming HTTP request.
 * @param res - server response.
 */
export declare function handleExcalidrawRequest(resolveCwd: GitCwdResolver, req: IncomingMessage, res: ServerResponse): Promise<void>;
//# sourceMappingURL=excalidraw-service.d.ts.map