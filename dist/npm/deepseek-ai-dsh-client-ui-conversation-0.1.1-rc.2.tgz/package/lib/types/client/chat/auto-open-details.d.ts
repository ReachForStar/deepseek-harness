import type { ConversationSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
/** One settled file-mutation call, with the identity a SelectionTarget needs. */
export interface SettledDiffCall {
    callId: string;
    /** Turn number from the node location; 0 when the node carries none (details resolves by callId). */
    turn: number;
    /** Tool display name, falling back to the callId when the head left the window. */
    name: string;
}
/**
 * Collect the session's settled file-mutation calls in node-store iteration
 * order. A running or errored mutation is excluded: without an applied diff
 * there is nothing for the details panel to show.
 * @param nodes - the session's chat node store.
 * @returns settled diff calls in store order.
 */
export declare function settledDiffCalls(nodes: ConversationSnapshot['chat']['nodes']): SettledDiffCall[];
//# sourceMappingURL=auto-open-details.d.ts.map