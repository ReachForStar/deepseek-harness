import type { IncomingMessage, ServerResponse } from 'node:http';
/** The on-disk image file (profile-directory sibling; survives restarts). */
export declare const BACKGROUND_IMAGE_FILE = "background-image";
/**
 * Handle one `/bg` request.
 * @param imagePath - absolute path of the persisted image file.
 * @param maxBytes - upload cap.
 * @param req - incoming HTTP request.
 * @param res - server response.
 */
export declare function handleBackgroundRequest(imagePath: string, maxBytes: number, req: IncomingMessage, res: ServerResponse): Promise<void>;
//# sourceMappingURL=background-service.d.ts.map