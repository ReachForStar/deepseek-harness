import type { Context } from '@deepseek-ai/cordis';
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import { type PolishSettings } from '../background-settings.ts';
import { type RateCardData } from './cost.ts';
/**
 * Model rate card owner: adopts the durable user card, serves the effective
 * card to the stats float, and persists validated edits through the scope.
 */
export declare class PricingRuntime {
    private readonly host;
    private effective;
    /**
     * @param ctx - owning context (scope subscription rides ctx.effect).
     * @param host - durable preference scope bound by the owning plugin.
     */
    constructor(ctx: Context, host: SettingsScope<PolishSettings>);
    /** The card currently pricing the float (the user card or the seed).
     * @returns the effective rate card.
     */
    getCard(): RateCardData;
    /** The durable JSON text of the user card, or null when unset.
     * @returns the persisted card JSON, or null.
     */
    getUserJson(): string | null;
    /**
     * Validate and persist a user card. The scope write happens only after the
     * JSON parses; the effective card updates immediately.
     * @param json - rate card JSON text (the `model-pricing.json` shape).
     * @throws {Error} with a field-level message when the card is invalid.
     */
    save(json: string): void;
    /** Clear the user card back to the built-in seed. */
    reset(): void;
    /** Adopt the scope's durable user card without writing it back. */
    private adopt;
}
//# sourceMappingURL=pricing-store.d.ts.map