/**
 * Fixed Pi coding agent one-shot subagent provider. Every accepted run starts
 * a fresh `pi --mode rpc` process in the delegating Session's workspace and
 * publishes only after the RPC server answered a readiness probe.
 *
 * @module @deepseek-ai/dsh-subagent-pi
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "subagent-pi";
export declare const inject: string[];
/** Deployment-owned environment, process-release bounds, and Pi directories. */
export interface Config {
    /**
     * Explicit environment entries layered over the subprocess seam's
     * credential-scrubbed parent environment. Pi credentials (for example
     * `DEEPSEEK_API_KEY`) and any Pi extension variables belong here.
     */
    env?: Record<string, string>;
    /** Grace in milliseconds for Pi's cooperative EOF shutdown before termination. */
    disposeEofGraceMs?: number;
    /** Grace in milliseconds for app-server process-tree termination. */
    disposeGraceMs?: number;
    /**
     * Pi executable (bare name on `PATH`) or a test fixture launcher; the
     * provider appends `--mode rpc`.
     */
    command?: string;
    /** Fixed arguments appended after the Pi executable. */
    args?: string[];
    /**
     * Absolute `PI_CODING_AGENT_DIR` override naming where Pi keeps agent
     * settings and trust state. When omitted, Pi uses its native home
     * (`~/.pi/agent`). Wins over an `env.PI_CODING_AGENT_DIR` entry.
     */
    agentDir?: string;
    /**
     * Absolute `PI_CODING_AGENT_SESSION_DIR` override naming where Pi keeps
     * session files. When omitted, Pi uses its native session location. Wins
     * over an `env.PI_CODING_AGENT_SESSION_DIR` entry.
     */
    sessionDir?: string;
}
export declare const Config: z<Config>;
/**
 * Register the fixed `pi` provider.
 * @param ctx - context carrying shared subagent and subprocess services.
 * @param config - child environment, process-release bounds, and Pi directories.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map